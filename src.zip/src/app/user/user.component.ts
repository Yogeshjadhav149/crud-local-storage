import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
    allUsers:any;
  user:any={};
  myUser:any={};
  
  formdata:any;
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
      // this.user=new FormGroup({
      //   username: new FormControl("",[Validators.required]),
      //   gender:new FormControl("",[Validators.required]),
      //   qualification:new FormControl("",[Validators.required]),
      //   city:new FormControl("",[Validators.required])
      // })
     
      this.createform();
      this.getUser();
  }

  createform(){
    this.formdata=this.fb.group({
        username:["",Validators.required],
        gender:["",Validators.required],
        qualification:["",Validators.required],
        city:["",Validators.required]
      })
  }

  Submit(){
       this.user=Object.assign(this.user,this.formdata.value);
       this.adduser(this.user);
       this.getUser();
     
       this.formdata.reset();
    }
    
     
    adduser(user:any){
      let users=[];
      if(localStorage.getItem('Users')){

        users=JSON.parse(localStorage.getItem('Users') || '[]');
        users=[...users,user];
      }
      else{
        users=[user];
      }
      localStorage.setItem('Users',JSON.stringify(users));

      
    }

    getUser(){
      
          this.allUsers=JSON.parse(localStorage.getItem('Users') || '[]');
              console.log(this.allUsers);
    }

    deleteUser(index:any){
       this.allUsers.splice(index,1);
      localStorage.setItem('Users',JSON.stringify(this.allUsers));
      
      }
     
}
